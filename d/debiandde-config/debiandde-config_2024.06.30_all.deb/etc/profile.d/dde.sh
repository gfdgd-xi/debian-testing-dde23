#!/bin/bash
export PATH=$PATH:/sbin
export QT_QPA_PLATFORMTHEME=deepin