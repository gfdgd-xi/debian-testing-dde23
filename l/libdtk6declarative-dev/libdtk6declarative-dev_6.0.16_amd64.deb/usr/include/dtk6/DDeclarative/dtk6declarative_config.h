// SPDX-FileCopyrightText: 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later

#define DTK6DECLARATIVE_CLASS_DAppLoader
#define DTK6DECLARATIVE_CLASS_DQmlAppMainWindowInterface
#define DTK6DECLARATIVE_CLASS_DQmlAppPreloadInterface
#define DTK6DECLARATIVE_CLASS_DQuickBlitFramebuffer
#define DTK6DECLARATIVE_CLASS_DQuickItemViewport
#define DTK6DECLARATIVE_CLASS_DQuickWindow
