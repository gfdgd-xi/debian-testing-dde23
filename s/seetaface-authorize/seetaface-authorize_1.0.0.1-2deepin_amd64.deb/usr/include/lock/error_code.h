#ifndef ERROR_CODE_H_
    #define ERROR_CODE_H_

    #include <string>


    std::string error_str( int error_code );

#endif
