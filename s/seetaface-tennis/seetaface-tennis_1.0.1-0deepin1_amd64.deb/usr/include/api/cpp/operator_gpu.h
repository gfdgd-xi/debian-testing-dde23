//
// Created by kier on 19-5-18.
//

#ifndef TENNIS_API_CPP_OPERATOR_GPU_H
#define TENNIS_API_CPP_OPERATOR_GPU_H

#include "operator.h"
#include "../operator_gpu.h"

#endif //TENNIS_API_CPP_OPERATOR_GPU_H
